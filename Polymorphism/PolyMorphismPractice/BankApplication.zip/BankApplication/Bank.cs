using System;

namespace BankApplication
{
    public abstract class Bank
    {
        public abstract double GetInterestInfo();
    }
}
