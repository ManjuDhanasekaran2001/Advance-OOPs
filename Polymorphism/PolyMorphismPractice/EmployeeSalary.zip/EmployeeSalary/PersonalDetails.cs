using System;
using System.Net;

namespace EmployeeSalary
{
    public class PersonalDetails
    {
        public string Name { get; set; }
        public string Fathername { get; set; }
        public string Qualification { get; set; }
        public string Gender { get; set; }


        // public PersonalDetails(string name,string fathername, string gender, string qualification)
        // {
        //     Name = name;
        //      Fathername= fathername;
        //      Gender = gender;
        //      Qualification = qualification;

        // }

    }
}
