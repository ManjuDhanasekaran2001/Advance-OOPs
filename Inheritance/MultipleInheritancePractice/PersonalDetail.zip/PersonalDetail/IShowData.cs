using System;

namespace PersonalDetail
{
    public interface IShowData
    {
        void ShowInfo();
    }
}
