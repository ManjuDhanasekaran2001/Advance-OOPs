using System;

namespace BankingApplication
{
    public class PersonalInfo
    {
        
        public String Name  { get; set; }
        public string Gender { get; set; }

        public DateTime DOB {get;set;}
        public string Phone { get; set; }

    }
}
