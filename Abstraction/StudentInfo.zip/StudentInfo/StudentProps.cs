using System;

namespace StudentInfo
{
    public partial class StudentInfo
    {
        public string StudentID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string  DOB { get; set; }

        public string  Mobile { get; set; }
        public double PhysicsMark { get; set; }
        public double ChemistryMark { get; set; }
        public double  MathsMark { get; set; }
    }
}
