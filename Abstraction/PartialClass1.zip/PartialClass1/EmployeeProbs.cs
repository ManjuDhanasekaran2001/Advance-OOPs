using System;

namespace PartialClass1
{
    public partial class EmployeeInfo
    {
        public string EmployeeID { get; set; }
        public string Name { get; set; }
        public String Gender { get; set; }

        public string DOB { get; set; }

        public string Mobile { get; set; }
    }
}
