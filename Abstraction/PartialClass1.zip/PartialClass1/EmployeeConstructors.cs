using System;

namespace PartialClass1
{
    public partial class EmployeeInfo
    {
        public EmployeeInfo()
        {

        }
    }
}
