using System;

namespace StudentApplication
{
    public interface IDisplayInfo
    {
        void DisplayInfo();
    }
}
