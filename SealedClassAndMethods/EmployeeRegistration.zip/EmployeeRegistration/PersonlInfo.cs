using System;

namespace EmployeeRegistration
{
    public class PersonlInfo
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public string Phone { get; set; }
        public string MailID { get; set; }

        

    }
}
