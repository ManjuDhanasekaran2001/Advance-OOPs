using System;

namespace EmployeeRegistration
{
    // public class Hack:EmployeeInfo
    // {
        
    // }

    //We cannot inherit the sealed class
}
