using System;

namespace PatientDetails
{
    /*public class DoctorInfo:PatientInfo
    {
        
    }
    */

    //we cannaot inherit the sealed class Patient Info  is a sealed class
}
