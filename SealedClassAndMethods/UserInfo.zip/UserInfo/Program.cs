﻿using System;
namespace UserInfo;
class Program{
    public static void Main(string[] args)
    {
        EmployeeInfo employee = new EmployeeInfo();
        //we cannaot use the update method to set the values for the properties because the method Update is a sealed method
    }
}