using System;

namespace Calculator
{
    public abstract class Calculator
    {
        public abstract double Area();
        public abstract double Volume();
    }
}
